# Install required packages
install.packages(c("tidyverse", "caret", "randomForest", "e1071", "xgboost"))
